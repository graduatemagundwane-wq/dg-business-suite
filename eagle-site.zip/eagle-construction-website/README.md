# Eagle Construction Company — website

A responsive six-page website based on the four visual references provided. The navy/yellow Eagle Construction Company identity, ten service categories, phone **+263 71 827 2656**, and email **pardongondo4@gmail.com** are taken from the company's supplied flyer.

## Pages
Home · About Us · Services · Projects · Request a Quote · Contact · `/admin` (private enquiries)

## Run locally
1. Install Node.js 20 or newer.
2. In this directory, run `npm start`.
3. Open `http://localhost:3000`.

There are **no external npm dependencies**. Fonts use Google Fonts when connected to the internet, and local font fallbacks otherwise.

## Quotation form and uploaded files
The quote form submits to `/api/quote`, with name, phone, email, service, project location, detailed brief and up to **three files of 10 MB each**. Valid files: PDF, DWG, JPG, PNG. The site visit form submits to `/api/site-visit`. The backend saves a timestamped JSON enquiry and any uploaded drawings in `data/`. It returns a unique reference and can optionally hand the user to WhatsApp for follow-up.

The server does **not** automatically email the owner. To view stored enquiries, configure `ADMIN_PASSWORD` as an environment variable and visit `/admin`. Do not advertise email notifications unless and until an email integration is separately configured.

## Deployment
Deploy on any persistent Node.js host (such as Render, Railway or a Node-capable server). Set:
- `PORT` (host may provide this automatically)
- `ADMIN_PASSWORD` (long, unique password; **no default admin password**)
- `SESSION_SECRET` (random 32-byte or longer secret)
- `DATA_DIR` (path on a **persistent attached disk**, otherwise enquiries and uploads can be lost on redeployment)
- `NODE_ENV=production` when serving behind HTTPS

Start command: `npm start`. Health endpoint: `/health`. The web server should be served behind HTTPS. Secure admin cookies are used in production, so local HTTP admin login should run without `NODE_ENV=production`.

## Important content notes
The supplied images include webpage reference samples and a company flyer. Photos used for *project inspiration* are **illustrative** and are not presented as verified Eagle Construction Company completed projects. We deliberately did not invent customer reviews, business hours, branch address, years of experience, project counts or credentials. Confirm the company's service area, official project photography and any legal/registration details before public launch.

## Security
The backend validates fields, file types and file signatures; caps request sizes and rate-limits basic submissions and admin login. The admin dashboard uses signed, HTTP-only session cookies. Protect the host with TLS/HTTPS, configure persistent storage, and take backups of the `data/` directory. Stronger authentication, monitoring and anti-bot measures may be appropriate at larger scale.

## Design
The website retains the visual reference's general page hierarchy, image-led hero layouts, cards, quotation sections, steps and footer while updating the accent colours and content for the company flyer. Image assets were cropped from the images provided by the requester.
