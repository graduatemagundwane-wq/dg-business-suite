import http from 'node:http';
import fs from 'node:fs';
import {promises as fsp} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR=path.resolve(process.env.DATA_DIR || path.join(ROOT,'data'));
const LEADS_DIR=path.join(DATA_DIR,'leads');
const UPLOADS_DIR=path.join(DATA_DIR,'uploads');
const PORT=Number(process.env.PORT||3000);
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'';
const SECRET=process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const MAX_UPLOAD=10*1024*1024;
const MAX_REQUEST=33*1024*1024;
const SUPPORTED_EXTENSIONS=new Set(['.pdf','.dwg','.png','.jpg','.jpeg']);
const allowedRoutes=new Set(['/','/about','/services','/projects','/contact','/request-a-quote','/admin']);
const rateMap=new Map();
await Promise.all([fsp.mkdir(LEADS_DIR,{recursive:true,mode:0o700}),fsp.mkdir(UPLOADS_DIR,{recursive:true,mode:0o700})]);

function send(res,status,body,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers});res.end(JSON.stringify(body));}
function ipOf(req){return (req.socket.remoteAddress||'unknown').slice(0,80);}
function limited(key,limit,interval){const now=Date.now();let entry=rateMap.get(key);if(!entry||now-entry.start>interval){entry={start:now,count:0};rateMap.set(key,entry);}entry.count++;if(rateMap.size>5000){for(const [k,v] of rateMap){if(now-v.start>3600000)rateMap.delete(k);}}return entry.count>limit;}
async function readBody(req,limit){let size=0;const buffers=[];for await (const chunk of req){size+=chunk.length;if(size>limit){const e=new Error('Request exceeds maximum permitted size');e.status=413;throw e;}buffers.push(chunk);}return Buffer.concat(buffers);}
function safeText(value,max=3000){return String(value??'').replace(/\0/g,'').trim().slice(0,max);}
function requireFields(d,names){for(const name of names){if(!safeText(d[name])){const e=new Error(`Please provide ${name.replaceAll('_',' ')}.`);e.status=400;throw e;}}if(safeText(d.name).length<2||safeText(d.details).length<10){const e=new Error('Please provide your full name and at least 10 characters describing the project.');e.status=400;throw e;}}
function parseMultipart(buf,header){const match=header.match(/boundary=(?:"([^"]+)"|([^;]+))/i);if(!match)throw new Error('No form-data boundary found.');const boundary=Buffer.from(`--${match[1]||match[2]}`,'latin1');const fields={};const files=[];let start=buf.indexOf(boundary);if(start<0)throw new Error('Invalid multipart form data.');while(start>=0){let p=start+boundary.length;if(buf[p]===45&&buf[p+1]===45)break;if(buf[p]===13&&buf[p+1]===10)p+=2;const headerEnd=buf.indexOf(Buffer.from('\r\n\r\n'),p);if(headerEnd<0)break;const headerText=buf.subarray(p,headerEnd).toString('latin1');const next=buf.indexOf(boundary,headerEnd+4);if(next<0)break;const content=buf.subarray(headerEnd+4,Math.max(headerEnd+4,next-2));const disposition=headerText.match(/content-disposition:\s*form-data;\s*name="([^"]+)"(?:;\s*filename="([^"]*)")?/i);if(disposition){const name=disposition[1],originalName=disposition[2];if(typeof originalName==='string'&&originalName.length>0){files.push({field:name,originalName:path.basename(originalName.replaceAll('\\','/')).slice(0,150),bytes:content});}else{fields[name]=content.toString('utf8').slice(0,10000);}}start=next;}return {fields,files};}
function checkSignature(extension,bytes){if(extension==='.pdf')return bytes.subarray(0,5).toString()==='%PDF-';if(extension==='.png')return bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));if(extension==='.jpg'||extension==='.jpeg')return bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255;if(extension==='.dwg')return /^AC10\d{2}/.test(bytes.subarray(0,6).toString());return false;}
function validateFiles(files){if(files.length>3){const e=new Error('Please upload at most 3 files.');e.status=400;throw e;}for(const file of files){const ext=path.extname(file.originalName).toLowerCase();if(file.bytes.length===0||file.bytes.length>MAX_UPLOAD||!SUPPORTED_EXTENSIONS.has(ext)||!checkSignature(ext,file.bytes)){const e=new Error('Each file must be a valid PDF, DWG, JPG or PNG, under 10 MB.');e.status=400;throw e;}}}
function newReference(){return `EC-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;}
async function saveLead(data,files,type){const id=crypto.randomUUID(),reference=newReference(),createdAt=new Date().toISOString();const record={id,reference,createdAt,type,name:safeText(data.name,120),phone:safeText(data.phone,25),email:safeText(data.email,180),location:safeText(data.location,180),details:safeText(data.details),service:safeText(data.service,90),preferred_date:safeText(data.preferred_date,12),files:[]};if(files.length){const dir=path.join(UPLOADS_DIR,id);await fsp.mkdir(dir,{recursive:true,mode:0o700});for(let i=0;i<files.length;i++){const file=files[i];const ext=path.extname(file.originalName).toLowerCase();const fileName=`plan-${i+1}${ext}`;await fsp.writeFile(path.join(dir,fileName),file.bytes,{flag:'wx',mode:0o600});record.files.push({originalName:file.originalName,storedName:fileName,size:file.bytes.length});}}await fsp.writeFile(path.join(LEADS_DIR,`${id}.json`),JSON.stringify(record),{flag:'wx',mode:0o600});return {reference};}
function cookieParse(req){const raw=req.headers.cookie||'';const result={};for(const p of raw.split(';')){const idx=p.indexOf('=');if(idx>0)result[p.slice(0,idx).trim()]=p.slice(idx+1).trim();}return result;}
function authToken(){const payload=Buffer.from(JSON.stringify({exp:Date.now()+12*60*60*1000})).toString('base64url');const signature=crypto.createHmac('sha256',SECRET).update(payload).digest('base64url');return `${payload}.${signature}`;}
function signedIn(req){const token=cookieParse(req).ec_admin||'';const [body,sig]=token.split('.');if(!body||!sig)return false;const expected=crypto.createHmac('sha256',SECRET).update(body).digest('base64url');if(sig.length!==expected.length||!crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected)))return false;try{return JSON.parse(Buffer.from(body,'base64url').toString()).exp>Date.now();}catch{return false;}}
const assetMime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg'};
async function serveFile(res,file,cache='public, max-age=86400'){const full=path.resolve(ROOT,file);if(!full.startsWith(ROOT+path.sep))return send(res,403,{error:'Forbidden'});try{const stat=await fsp.stat(full);if(!stat.isFile())throw new Error('not a file');const ext=path.extname(full).toLowerCase();res.writeHead(200,{'Content-Type':assetMime[ext]||'application/octet-stream','Content-Length':stat.size,'Cache-Control':cache,'X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});fs.createReadStream(full).pipe(res);}catch{send(res,404,{error:'Not found'});}}
async function handle(req,res){const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`),pathname=decodeURIComponent(url.pathname);try{
 if(req.method==='GET'&&pathname==='/health'){return send(res,200,{ok:true,service:'eagle-construction-website'});}
 if(req.method==='POST'&&pathname==='/api/quote'){
  if(limited(`quote:${ipOf(req)}`,8,60*60*1000))return send(res,429,{error:'Too many requests. Please contact us directly.'});
  const contentType=req.headers['content-type']||'';if(!contentType.includes('multipart/form-data'))return send(res,415,{error:'Please submit form data.'});
  const {fields,files}=parseMultipart(await readBody(req,MAX_REQUEST),contentType);if(fields.company_website)return send(res,200,{reference:'EC-RECEIVED'});
  requireFields(fields,['name','phone','email','location','service','details']);if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email))return send(res,400,{error:'Please enter a valid email.'});
  validateFiles(files);return send(res,201,await saveLead(fields,files.filter(f=>f.field==='plans'),'quotation'));
 }
 if(req.method==='POST'&&pathname==='/api/site-visit'){
  if(limited(`site:${ipOf(req)}`,8,60*60*1000))return send(res,429,{error:'Too many requests. Please contact us directly.'});
  const fields=JSON.parse((await readBody(req,65536)).toString('utf8'));if(fields.company_website)return send(res,200,{reference:'EC-RECEIVED'});
  requireFields(fields,['name','phone','location','preferred_date','details']);if(!/^\d{4}-\d{2}-\d{2}$/.test(fields.preferred_date))return send(res,400,{error:'Please provide a valid date.'});
  return send(res,201,await saveLead(fields,[],'site-visit'));
 }
 if(req.method==='POST'&&pathname==='/api/admin/login'){
  if(!ADMIN_PASSWORD)return send(res,503,{error:'Admin access is not configured. Set ADMIN_PASSWORD on the server.'});
  if(limited(`login:${ipOf(req)}`,6,15*60*1000))return send(res,429,{error:'Too many sign-in attempts.'});
  const fields=JSON.parse((await readBody(req,65536)).toString('utf8'));
  const got=Buffer.from(String(fields.password??'')),wanted=Buffer.from(ADMIN_PASSWORD);
  if(got.length!==wanted.length||!crypto.timingSafeEqual(got,wanted))return send(res,401,{error:'Incorrect password.'});
  const secure=process.env.NODE_ENV==='production'?'; Secure':'';return send(res,200,{ok:true},{'Set-Cookie':`ec_admin=${authToken()}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${secure}`});
 }
 if(req.method==='POST'&&pathname==='/api/admin/logout')return send(res,200,{ok:true},{'Set-Cookie':'ec_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
 if(req.method==='GET'&&pathname==='/api/admin/leads'){
  if(!signedIn(req))return send(res,401,{error:'Authentication required.'});
  const entries=await fsp.readdir(LEADS_DIR);const records=[];for(const name of entries){if(!name.endsWith('.json'))continue;try{records.push(JSON.parse(await fsp.readFile(path.join(LEADS_DIR,name),'utf8')));}catch{}}
  records.sort((a,b)=>b.createdAt.localeCompare(a.createdAt));return send(res,200,records);
 }
 if(req.method==='GET'&&pathname.startsWith('/api/admin/download/')){
  if(!signedIn(req))return send(res,401,{error:'Authentication required.'});
  const parts=pathname.split('/'),id=parts[4],index=Number(parts[5]);if(!/^[0-9a-f-]{36}$/.test(id)||!Number.isInteger(index)||index<0||index>2)return send(res,404,{error:'Not found'});
  const record=JSON.parse(await fsp.readFile(path.join(LEADS_DIR,`${id}.json`),'utf8'));const file=record.files?.[index];if(!file)return send(res,404,{error:'File not found'});
  const p=path.join(UPLOADS_DIR,id,file.storedName);res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename="${file.originalName.replace(/[^a-zA-Z0-9._-]/g,'_')}"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});return fs.createReadStream(p).pipe(res);
 }
 if(req.method==='GET'&&pathname.startsWith('/assets/'))return serveFile(res,pathname.slice(1),'public, max-age=604800');
 if(req.method==='GET'&&pathname==='/styles.css')return serveFile(res,'styles.css');
 if(req.method==='GET'&&pathname==='/app.js')return serveFile(res,'app.js');
 if(req.method==='GET'&&allowedRoutes.has(pathname.replace(/\/$/,'')||'/'))return serveFile(res,'index.html','no-cache');
 return send(res,404,{error:'Page not found'});
 }catch(err){console.error('Request error',err?.message);const status=err.status||((err instanceof SyntaxError)?400:500);return send(res,status,{error:status===500?'An unexpected error occurred. Please try again.':err.message});}}
const server=http.createServer(handle);
server.listen(PORT,process.env.HOST||'0.0.0.0',()=>console.log(`Eagle Construction Company site at http://localhost:${PORT}`));
export {server};
