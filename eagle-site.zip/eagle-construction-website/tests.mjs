import test, {after,before} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
let proc,dir;
const PORT=42917;
const origin=`http://127.0.0.1:${PORT}`;
before(async()=>{
  dir=await mkdtemp(path.join(os.tmpdir(),'eagle-test-'));
  proc=spawn(process.execPath,['server.mjs'],{cwd:process.cwd(),env:{...process.env,PORT:String(PORT),HOST:'127.0.0.1',DATA_DIR:dir,ADMIN_PASSWORD:'TestWithUniquePassword!42',SESSION_SECRET:'testsecretabcdefgh0123456789'},stdio:'ignore'});
  for(let i=0;i<50;i++){
    try{const res=await fetch(`${origin}/health`);if(res.ok)return;}catch{}
    await new Promise(resolve=>setTimeout(resolve,80));
  }
  throw new Error('Test server failed to start');
});
after(async()=>{proc?.kill();if(dir)await rm(dir,{recursive:true,force:true});});
test('six page routes, styles, JavaScript and company logo are served',async()=>{
  for(const route of ['/','/about','/services','/projects','/request-a-quote','/contact','/admin']){
    const res=await fetch(origin+route);assert.equal(res.status,200,route);assert.match(await res.text(),/Eagle Construction Company/);
  }
  for(const route of ['/styles.css','/app.js','/assets/eagle-head.png'])assert.equal((await fetch(origin+route)).status,200);
});
test('health returns site status',async()=>{
  const r=await fetch(origin+'/health');assert.equal(r.status,200);assert.equal((await r.json()).ok,true);
});
test('quote accepts data and an uploaded PDF',async()=>{
  const form=new FormData();for(const [key,value] of Object.entries({name:'Example Customer',phone:'0712345678',email:'customer@example.com',service:'House Construction',location:'Harare',details:'I need a construction project quotation.'}))form.append(key,value);
  form.append('plans',new Blob(['%PDF-1.4\n1 0 obj\n<<>>\n%%EOF'],{type:'application/pdf'}),'drawing.pdf');
  const r=await fetch(origin+'/api/quote',{method:'POST',body:form});assert.equal(r.status,201);const data=await r.json();assert.match(data.reference,/^EC-\d{8}-[A-Z0-9]{6}$/);
});
test('invalid uploaded content is rejected',async()=>{
  const form=new FormData();for(const [key,value] of Object.entries({name:'Example Customer',phone:'0712345678',email:'customer@example.com',service:'Plumbing',location:'Harare',details:'I need a plumbing project quotation.'}))form.append(key,value);
  form.append('plans',new Blob(['not a PDF'],{type:'application/pdf'}),'bad.pdf');
  const r=await fetch(origin+'/api/quote',{method:'POST',body:form});assert.equal(r.status,400);
});
test('site visit can be requested',async()=>{
  const r=await fetch(origin+'/api/site-visit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'Example Person',phone:'0712345678',location:'Ruwa',preferred_date:'2026-11-11',details:'I need to assess foundations on our site.'})});assert.equal(r.status,201);assert.match((await r.json()).reference,/^EC-/);
});
test('admin access requires password, lists enquiries and downloads drawing',async()=>{
  assert.equal((await fetch(origin+'/api/admin/leads')).status,401);
  const bad=await fetch(origin+'/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'wrong'})});assert.equal(bad.status,401);
  const response=await fetch(origin+'/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'TestWithUniquePassword!42'})});assert.equal(response.status,200);
  const cookie=response.headers.get('set-cookie').split(';')[0];
  const leads=await (await fetch(origin+'/api/admin/leads',{headers:{Cookie:cookie}})).json();assert.equal(leads.length,2);
  const quote=leads.find(x=>x.type==='quotation');assert.equal(quote.files[0].originalName,'drawing.pdf');
  const download=await fetch(origin+`/api/admin/download/${quote.id}/0`,{headers:{Cookie:cookie}});assert.equal(download.status,200);assert.equal((await download.text()).slice(0,5),'%PDF-');
});
